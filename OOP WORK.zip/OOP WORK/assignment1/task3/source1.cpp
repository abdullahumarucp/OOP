#include"Name.h"

int main()
{
	Name n1 ,n2;
	char f_name[20] = { '\0' };
	char l_name[20] = { '\0' };
	cout << "Enter First Name : "; cin >> f_name;
	cout << "Enter Last Name : "; cin >> l_name;
	n1.setFirstName(f_name);
	n1.setLastName(l_name);
	cout << "Object 1 ";
	n1.display();

	cout << endl;
	n2.copyName(n1);
	cout << "Object 2 ";
	n2.display();

	cout << endl;
	Name n3 = n1;
	cout << "\nObject 3 ";
	n3.display();

	cout << endl;
	n3.swapNames();
	n3.display();
	
	cout << endl;
	n1.toUpper();
	n1.display();

	cout << endl;
	n1.toLower();
	n1.display();

	cout << endl;
	n1.camelCase();
	n1.display();

	cout << endl;
	int len = n1.nameLength();
	cout << endl << "Name Length(without Space) is : " << len;

	cout << endl;
	char* full_name = n1.fullName();
	cout << "\nFull Name is : " << full_name;
	delete[] full_name;

	cout << endl;
	bool valid = n1.isValidName();

	if (valid == 1)
		cout << endl << "This is a Valid Name";
	if (valid == 0)
		cout << endl << "This is a InValid Name";


	cout << endl;


	return 0;
}