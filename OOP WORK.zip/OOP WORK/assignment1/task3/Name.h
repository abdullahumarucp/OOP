#include<iostream>
using namespace std;
class Name 
{
private:
	char* firstname;
	char* lastname;
public:
	void setFirstName(char*);
	void setLastName(char*);
	char* getFirstName();
	char* getlastName();
	Name(char* first = nullptr, char* last = nullptr);
	Name(const Name&);
	~Name();
	void copyName(Name&);
	void camelCase();
	void toLower();
	void toUpper();
	int nameLength();
	void swapNames();
	void display();
	char* fullName();
	bool isValidName();

};
