#include "Name.h"


void Name::copyName(Name &otherobj )
{
	cout << "Copy Name()" << endl;
	int len = 0;			
	int len1 = 0;			
	while (true)		//first name length
	{
		if (otherobj.firstname[len] == '\0')		
			break;
		else
			len++;
	}
	while (true)		// last name lenght
	{
		if (otherobj.lastname[len1] == '\0')
			break;
		else
			len1++;
	}
	firstname = new char[len + 1];
	lastname = new char[len1 + 1];


	for (int i = 0; i < len; i++)
		firstname[i] = otherobj.firstname[i];

	firstname[len] = '\0';


	for (int i = 0; i < len1; i++)
		lastname[i] = otherobj.lastname[i];

	lastname[len1] = '\0';
}
void Name::camelCase()
{
	cout << "Camel Case()" << endl;
	if (firstname[0] >= 97 && firstname[0] <= 122)   //checking if fist letter is  small
		firstname[0] = firstname[0] - 32;


	if (lastname[0] >= 97 && lastname[0] <= 122)   //checking if fist letter is small
		lastname[0] = lastname[0] - 32;
}
void Name::toLower()
{
	cout << "Tolower()" << endl;
	for (int i = 0; firstname[i] != '\0'; i++)
	{
		if (firstname[i] >= 65 && firstname[i] <= 90)
			firstname[i] = firstname[i] + 32;
	}

	for (int i = 0; lastname[i] != '\0'; i++)
	{
		if (lastname[i] >= 65 && lastname[i] <= 90)
			lastname[i] = lastname[i] + 32;
	}
}
void Name::toUpper()
{
	cout << "toUpper()" << endl;
	for (int i = 0; firstname[i] != '\0'; i++)
	{
		if (firstname[i] >= 97 && firstname[i] <= 122)
			firstname[i] = firstname[i] - 32;
	}

	for (int i = 0; lastname[i] != '\0'; i++)
	{
		if (lastname[i] >= 97 && lastname[i] <= 122)
			lastname[i] = lastname[i] - 32;
	}
}
int Name::nameLength()
{
	cout << "nameLength()" << endl;
	int len = 0;
	for (int i = 0; firstname[i] != '\0'; i++)
	{
		len++;
	}
	for (int i = 0; lastname[i] != '\0'; i++)
	{
		len++;
	}

	return len;
}
void Name::swapNames()
{
	cout << "swapNames()" << endl;
	int length = 0;
	while (true)
	{
		if (firstname[length] == '\0')
			break;
		else
			length++;
	}
	char* temp = new char[length + 1];
	for (int i = 0; i < length; i++)
		temp[i] = firstname[i];

	temp[length] = '\0';

	length = 0;
	while (true)
	{
		if (lastname[length] == '\0')
			break;
		else
			length++;
	}
	delete firstname;
	firstname = new char[length + 1];

	for (int i = 0; i < length; i++)
		firstname[i] = lastname[i];

	firstname[length] = '\0';

	length = 0;
	while (true)
	{
		if (temp[length] == '\0')
			break;
		else
			length++;
	}
	delete lastname;
	lastname = new char[length + 1];

	for (int i = 0; i < length; i++)
		lastname[i] = temp[i];

	lastname[length] = '\0';
}
void Name::display()
{
	cout << endl << "Displaying Data" << endl;
	cout << "First Name : " << firstname << endl;
	cout << "Last Name : "  << lastname << endl;
}
char* Name::fullName()
{
	
	int len = 1;  // len = 1 for space in between
	for (int i = 0; firstname[i] != '\0'; i++)
	{
		len++;
	}
	for (int i = 0; lastname[i] != '\0'; i++)
	{
		len++;
	}

	char* fullName = new char[len + 1];

	int j = 0;
	for (int i = 0; firstname[i] != '\0'; i++)
	{
		fullName[i] = firstname[i];
		j++;
	}
	fullName[j++] = ' ';  // space
	for (int i = 0; lastname[i] != '\0'; i++)
	{
		fullName[j] = lastname[i];
		j++;
	}
	fullName[len] = '\0';
	return fullName;
}
bool Name::isValidName()
{
	bool check = true;
	// check = 1 if name is valid
	// check = 0 if name is invalid
	for (int i = 0; firstname[i] != '\0'; i++)
	{
		if ((firstname[i] >= 65 && firstname[i] <= 90) || (firstname[i] >= 97 && firstname[i] <= 122))
		{
			check = 1;
		}
		else
		{
			check = 0;
			break;
		}
	}
	if (check != 0)		// if first name had any specal char than no need to check last name
	{
		for (int i = 0; lastname[i] != '\0'; i++)
		{
			if ((lastname[i] >= 65 && lastname[i] <= 90) || (lastname[i] >= 97 && lastname[i] <= 122))
			{
				check = 1;
			}
			else
			{
				check = 0;
				break;
			}
		}
	}

	return check;
}



// setters and getters for first and last name
void Name::setFirstName(char* n)
{
	int length = 0;
	while (true)
	{
		if (n[length] == '\0')
			break;
		else
			length++;
	}

	firstname = new char[length + 1];

	for (int i = 0; i < length; i++)
		firstname[i] = n[i];

	firstname[length] = '\0';
}

void Name::setLastName(char* n)
{
	int length = 0;
	while (true)
	{
		if (n[length] == '\0')
			break;
		else
			length++;
	}

	lastname = new char[length + 1];

	for (int i = 0; i < length; i++)
		lastname[i] = n[i];

	lastname[length] = '\0';
}

char* Name::getFirstName()
{

	int length = 0;
	while (true)
	{
		if (firstname[length] == '\0')
			break;
		else
			length++;
	}

	char* temp = new char[length + 1];

	for (int i = 0; i < length; i++)
		temp[i] = firstname[i];

	temp[length] = '\0';

	return temp;
}

char* Name::getlastName()
{

	int length = 0;
	while (true)
	{
		if (lastname[length] == '\0')
			break;
		else
			length++;
	}

	char* temp = new char[length + 1];

	for (int i = 0; i < length; i++)
		temp[i] = lastname[i];

	temp[length] = '\0';

	return temp;
}


Name::Name(char* first , char* last )		
{
	cout << "Parameterized Constructor" << endl;
	firstname = first;
	lastname = last;
}
Name::Name(const Name& otherobj) 
{
	cout << "Copy Constructor" << endl;
	int len = 0;
	while (1)		// first name length
	{
		if (otherobj.firstname[len] == '\0')
			break;
		else
			len++;
	}
	firstname = new char[len + 1];

	int len1 = 0;
	while (1)				// last name lenght
	{
		if (otherobj.lastname[len1] == '\0')
			break;
		else
			len1++;
	}
	lastname = new char[len1 + 1];

	for (int i = 0; i < len; i++)
		firstname[i] = otherobj.firstname[i];		// coping first name

	firstname[len] = '\0';

	for (int i = 0; i < len1; i++)
		lastname[i] = otherobj.lastname[i];		// coping last name 

	lastname[len1] = '\0';
}
Name::~Name()	
{
	cout << endl << "~Name()";		//destructor
	if (firstname != nullptr)
	{
		delete[] firstname;
		firstname = nullptr;
	}

	if (lastname != nullptr)
	{
		delete[] lastname;
		lastname = nullptr;
	}

}
