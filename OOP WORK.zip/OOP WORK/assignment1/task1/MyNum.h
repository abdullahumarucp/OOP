#include<iostream>
using namespace std;

class MyNum
{
	double Num;
public:
	MyNum();
	MyNum(double );
	void setNum(double);
	double getNum();
	void positiveNum();
	void negativeNum();
};