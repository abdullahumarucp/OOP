#include<iostream>
using namespace std;

class MyChar
{
	char Num;
public:
	MyChar();
	MyChar(char);
	void setChar(char);
	char getChar();
	void upperChar();
	void lowerChar();
};