#include<iostream>
using namespace std;

class Date{
private:
	int day;
	int month;
	int year;


public:

	Date();
	Date(int, int, int);
	Date add(const Date&);
	Date sub(const Date&);
	Date operator + (const Date&);
	Date operator -(const Date&);
	Date& operator++();
	Date& operator--();
	Date operator++(int);
	Date operator--(int);
	void display();



};