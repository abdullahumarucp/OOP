#include"Date.h"



Date::Date(){
	cout << "default constructor : " << endl;
}
Date::Date(int d, int m, int y){

	day = d;
	month = m;
	year = y;

	cout << "constructor overloading : " << endl;
}

Date Date::add(const Date&p1){
	Date p;
	if (p.day>30)
	{
		month++;
		int q = (p1.day / 30);
		int r = (p1.day % 30);
		p.day = day + r;
		p.month = month + q;
	}
	if (p.month>12)
	{
		year++;
		p.month = month + (p1.month % 12);
		p.year = year + (p1.month / 12);
	}
	p.day = day + p1.day;
	p.month = month + p1.month;
	p.year = year + p1.year;



	return p;
}
Date Date::sub(const Date&p1){
	Date p;
	if (p.day>30)
	{
		month++;
		int q = (p1.day / 30);
		int r = (p1.day % 30);
		p.day = day + r;
		p.month = month + q;
	}
	if (p.month>12)
	{
		year++;
		p.month = month + (p1.month % 12);
		p.year = year + (p1.month / 12);
	}
	p.day = day - p1.day;
	p.month = month - p1.month;
	p.year = year - p1.year;



	return p;

}
Date Date:: operator + (const Date&p1){
	Date p;
	if (p.day>30)
	{
		month++;
		int q = (p1.day / 30);
		int r = (p1.day % 30);
		p.day = day + r;
		p.month = month + q;
	}
	if (p.month>12)
	{
		year++;
		p.month = month + (p1.month % 12);
		p.year = year + (p1.month / 12);
	}
	p.day = day + p1.day;
	p.month = month + p1.month;
	p.year = year + p1.year;



	return p;

}
Date Date:: operator -(const Date&p1){

	Date p;


	p.day = day - p1.day;
	p.month = month - p1.month;
	p.year = year - p1.year;



	return p;

}
Date& Date::operator++(){

	day = day + 1;

	return *this;

}
Date& Date::operator--(){

	day = day - 1;

	return *this;

}
Date Date::operator++(int){
	Date p;

	day = day + 1;

	return p;

}
Date Date::operator--(int){
	Date p;

	day = day - 1;

	return p;

}

void Date::display(){
	cout << "date = " << day << "-" << month << "-" << year << endl;
}