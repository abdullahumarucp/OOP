#include"Date.h"
int main(){

	Date d1;
	Date d2(23, 7, 2002);
	d2.display();
	Date d3(15, 0, 0);
	Date d4 = d3.add(d2);
	d3.display();
	d4.display();

	system("pause");
	return 0;
}

