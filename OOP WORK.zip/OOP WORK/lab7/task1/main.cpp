#include"time.h"


int main(){

	Time t1(6, 25, 19);
	Time t2(10, 30, 40);
	t1.display();
	t2.display();
	Time t3 = t1.add(t2);
	cout << "Addition : " << endl;
	t3.display();
	Time t4 = t1.sub(t2);
	cout << "substraction : " << endl;
	t4.display();
	bool flag = t1 == t2;
	if (flag)
	{
		cout << " YES!!! The values are equal : " << endl;
	}
	else
	{
		cout << " NO!!! The values are not equal : " << endl;
	}
	system("pause");
	return 0;

}
