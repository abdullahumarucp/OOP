#include"time.h"

Time::Time(){
	cout << "default constructor" << endl;
}
Time::Time(int h, int m, int s){
	hours = new int;
	*hours = h;
	minutes = new int;
	*minutes = m;
	seconds = new int;
	*seconds = s;
	/*hours = h;
	minutes = m;
	seconds = s;*/

	cout << "peramitrized constructor" << endl;
}
Time::Time(const Time& t){
	hours = t.hours;
	minutes = t.minutes;
	seconds = t.seconds;
	cout << "copy constructor" << endl;
}
Time::~Time(){
	delete hours;
	hours = nullptr;
	delete minutes;
	minutes = nullptr;
	delete seconds;
	seconds = nullptr;
}
Time Time::add(const Time& t){
	Time t1;

	t1.hours = hours + *t.hours;
	t1.minutes = minutes + *t.minutes;
	t1.seconds = seconds + *t.seconds;
	return t1;
}
Time Time::sub(const Time& t){
	Time t1;
	t1.hours = hours - *t.hours;
	t1.minutes = minutes - *t.minutes;
	t1.seconds = seconds - *t.seconds;
	return t1;
}
Time Time :: operator +(const Time& t){
	Time t1;
	t1.hours = hours + *t.hours;
	t1.minutes = minutes + *t.minutes;
	t1.seconds = seconds + *t.seconds;
	return t1;

}
Time Time :: operator -(const Time& t){
	Time t1;
	*t1.hours = *hours + *t.hours;
	*t1.minutes = *minutes + *t.minutes;
	*t1.seconds = *seconds + *t.seconds;
	return t1;

}
bool Time::operator==(const Time& t){
	if (*hours == *t.hours&&*minutes == *t.minutes&&*seconds == *t.seconds)
	{
		return true;
	}
	return false;
}
void Time::display(){

	cout << "hours = " << *hours << endl;
	cout << "minutes = " << *minutes << endl;
	cout << "seconds = " << *seconds << endl;
}
