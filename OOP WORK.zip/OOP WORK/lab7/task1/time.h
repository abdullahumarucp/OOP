#include<iostream>
using namespace std;

class Time{
private:
	int* hours;
	int* minutes;
	int* seconds;


public:
	Time();
	Time(int, int, int);
	Time(const Time&);
	~Time();
	Time add(const Time&);
	Time sub(const Time&);
	Time operator + (const Time&);
	Time operator - (const Time&);
	bool operator ==(const Time&);

	void display();

};