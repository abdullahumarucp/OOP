#pragma once
#pragma once
#include<iostream>
using namespace std;
class driver
{
	char* name;
	int contact;
	char*address;
	int cnic;
	int ridesdone;
	double rating;
public:
	driver();
	driver(char*, char*);
	void setcontact(int);
	int getcontact();
	void setcnic(int);
	int getcnic();
	void setrating(double);
	double getrating();
	void setrd(int);
	int getrd();
	void display();
	~driver();
};


class rider
{
	char*name1;
	int contact1;
	double rating1;
	int t_cancel;

public:
	rider();
	rider(char*);
	void setcontact1(int);
	int getcontact1();
	void setcancel(int);
	int getcancel();
	void setrating1(double);
	double getrating1();
	void display1();
	~rider();
};



class ride
{
	char*location;
	char*destination;
	char*vehicle_no;
	int trackid;
	char*promo;
	double discount;

public:
	ride();
	ride(char*, char*, char*, char*);
	void settrackid(int);
	int gettrackid();
	void setdiscount(double);
	double getdiscount();
	void display();
	~ride();

};


