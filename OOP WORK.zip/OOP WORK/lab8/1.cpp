#include"task.h"

int main()
{
	driver d;
	driver d1("abdullah umer", "bahria nashaman 04 iris");
	d1.setcontact(1122);
	d1.setrd(10);
	d1.setcnic(234567892);
	d1.setrating(4.7);
	d1.display();


	rider r;
	rider r1("esha bajwa");
	r1.setcontact1(2211);
	r1.setrating1(4.8);
	r1.setcancel(15);
	r1.display1();

	ride v;
	ride v1("shadab colon house no esha", "billionier", "bugatti chiron", "study");
	v1.setdiscount(12.5);
	v1.settrackid(1145);
	v1.display();

	system("pause");
	return 0;
}
