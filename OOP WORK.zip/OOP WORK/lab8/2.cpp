#include "task.h"


driver::driver()
{
	cout << "default constructor" << endl;
	name = nullptr;
	address = nullptr;
	ridesdone = 0;
	rating = 0.0;
	cnic = 0;
	contact = 0;
}

driver::driver(char* a, char* b)
{
	int length = 0;
	for (int i = 0; a[i] != '\0'; i++)
	{
		length++;
	}
	name = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		name[i] = a[i];
	}

	name[length] = '\0';

	int len = 0;
	for (int i = 0; b[i] != '\0'; i++)
	{
		len++;
	}
	address = new char[len + 1];

	for (int i = 0; i < len; i++)
	{
		address[i] = b[i];
	}

	address[len] = '\0';
}


void driver::display()
{
	cout << "\n  Data of driver" << endl;
	cout << " name = " << name << "\n address = " << address << "\n contact = " << contact << "\n rides done = " << ridesdone << "\n rating = " << rating << "\n cnic = " << cnic << endl;
}

driver::~driver()
{
	delete[]name;
	name = nullptr;
	delete[]address;
	address = nullptr;
}

void driver::setcontact(int c)
{
	contact = c;
}

int driver::getcontact()
{
	return contact;
}

void driver::setcnic(int c)
{
	cnic = c;
}
int driver::getcnic()
{
	return cnic;
}

void driver::setrd(int r)
{
	ridesdone = r;
}
int  driver::getrd()
{
	return ridesdone;
}

void driver::setrating(double sr)
{
	rating = sr;
}
double driver::getrating()
{
	return rating;
}



rider::rider()
{
	cout << "\n \n \n default constructor 1" << endl;
	name1 = nullptr;
	contact1 = 0;
	t_cancel = 0;
	rating1 = 0;
}

rider::rider(char* n)
{
	int length = 0;
	for (int i = 0; n[i] != '\0'; i++)
	{
		length++;
	}
	name1 = new char[length + 1];

	for (int i = 0; i < length; i++)
	{
		name1[i] = n[i];
	}

	name1[length] = '\0';
}

rider:: ~rider()
{
	delete[]name1;
	name1 = nullptr;
}

void rider::setcontact1(int c)
{
	contact1 = c;
}
int rider::getcontact1()
{
	return contact1;
}

void rider::setrating1(double r)
{
	rating1 = r;
}

double rider::getrating1()
{
	return rating1;
}

void rider::setcancel(int c)
{
	t_cancel = c;
}

int rider::getcancel()
{
	return t_cancel;
}

void rider::display1()
{
	cout << "\n  Data of rider" << endl;
	cout << " name = " << name1 << "\n contact = " << contact1 << "\n rating = " << rating1 << "\n trips cancel = " << t_cancel << endl << endl;
}




ride::ride()
{
	cout << "\n default constructor 2" << endl;
	location = nullptr;
	destination = nullptr;
	vehicle_no = nullptr;
	trackid = 0;
	promo = nullptr;
	discount = 0;
}


ride::ride(char*l, char*d, char*p, char*v)
{
	//location
	int length = 0;
	for (int i = 0; l[i] != '\0'; i++)
	{
		length++;
	}
	location = new char[length + 1];
	for (int i = 0; i < length; i++)
	{
		location[i] = l[i];
	}
	location[length] = '\0';

	//destination
	int length1 = 0;
	for (int i = 0; d[i] != '\0'; i++)
	{
		length1++;
	}
	destination = new char[length1 + 1];
	for (int i = 0; i < length1; i++)
	{
		destination[i] = d[i];
	}
	destination[length1] = '\0';

	//promo

	int length2 = 0;
	for (int i = 0; p[i] != '\0'; i++)
	{
		length2++;
	}
	promo = new char[length2 + 1];
	for (int i = 0; i < length2; i++)
	{
		promo[i] = p[i];
	}
	promo[length2] = '\0';

	//vehical number
	int length3 = 0;
	for (int i = 0; v[i] != '\0'; i++)
	{
		length3++;
	}
	vehicle_no = new char[length3 + 1];
	for (int i = 0; i < length3; i++)
	{
		vehicle_no[i] = v[i];
	}
	vehicle_no[length3] = '\0';
}

ride::~ride()
{
	delete[]location;
	location = nullptr;
	delete[]destination;
	destination = nullptr;
	delete[]vehicle_no;
	vehicle_no = nullptr;
	delete[]promo;
	promo = nullptr;
}

void ride::settrackid(int t)
{
	trackid = t;
}

int ride::gettrackid()
{
	return trackid;
}

void ride::setdiscount(double d)
{
	discount = d;
}

double ride::getdiscount()
{
	return discount;
}

void ride::display()
{
	cout << "\n  Data of ride" << endl;
	cout << " location = " << location << "\n destination = " << destination << "\n vehical number = " << vehicle_no << "\n tracking id = " << trackid << "\n promo code = " << promo << "\n discount = " << discount << endl << endl;
}


