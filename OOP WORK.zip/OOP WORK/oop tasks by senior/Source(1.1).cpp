#include <iostream>
using namespace std;

class student {
	int x, y;
public:
	void getdata(int a ,int b);
	void display_data();

};
void student::getdata(int a,int b)
{
	x = a;
	y = b;
}
void student::display_data()
{
	cout << "Sum Is :" << x + y;
}
int main()
{
	student s1;
	s1.getdata(5,10);
	s1.display_data();

	return 0;
};