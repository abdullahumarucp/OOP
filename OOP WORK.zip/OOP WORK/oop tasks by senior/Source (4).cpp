#include <iostream>
using namespace std;

class Employee {
public:
	string Name;
	string Company;
	int Age;
    //	Function
	void intro()
	{
		cout << "Name - " << Name << endl;
		cout << "Company - " << Company << endl;
		cout << "Age - " << Age << endl;

	}
	//   Constructer 
	Employee(string n ,string c,int a) {
		Name = n;
		Company = c;
		Age = a;

	}
};

int main()
{
	Employee e1 = Employee("Ali Khan","AK",35);  //  constructer
	e1.intro();

	



}