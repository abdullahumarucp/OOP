#include <iostream>
using namespace std;

class albaraka {
public:
	string Account_title;
	string Account_type;
	int Account_number;
	float balance;
	float withdraw;
public:
	void display()
	{
		cout << "Account Title is " << Account_title << endl;
		cout << "Account Type  is " << Account_type << endl;
		cout << "Account Number  is " << Account_number << endl;
		cout << "Account Balance is " << balance << endl;
		cout << "Withdraw amount is " << withdraw << endl;
	}
	albaraka(string Acount_title, string Account_type, int Account_number, float balance, float withdraw)
	{
		Acount_title = "Ali";
		Account_type = Account_type;
		Account_number = Account_number;
		balance = balance;
		withdraw = withdraw;
	};

};

int main()
{
	albaraka  e1;
	e1.display();

}