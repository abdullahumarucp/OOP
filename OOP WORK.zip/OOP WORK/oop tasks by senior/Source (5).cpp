#include <iostream>
using namespace std;

class dummy
{
	int a;
public:
	dummy()
	{
		a = 0;
		cout << "I Am Dfault constructer" << endl;;
	}
	dummy(const dummy& d1)
	{
		cout << "I Am copy constructer ";
		a = d1.a;
	}
};
int main()
{
	dummy d1;
	dummy d2 = d1;
	return 0;
}