#include <iostream>
using namespace std;

class Employee {
private:
	string Name;
public:
	void setname(string n)
	{
		Name = n;
	}
	string getname()
	{
		return Name;
	}
};

int main()
{ 
	Employee e1;
	e1.setname("Ali");
	cout << "Employee Name is :" << e1.getname() << endl;


	system("pause");
}