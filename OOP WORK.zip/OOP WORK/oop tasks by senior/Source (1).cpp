#include <iostream>
using namespace std;
class ex {
public:
	int x;
public:
	void ex1(int a) {
		x = a;
	}
	void display();
	void operator-();
};
void ex::display()
{
	cout << "X is :" << x<<endl;
}
void ex::operator-()
{
	x = -x;
}
int main()
{
     ex obj;
	obj.ex1(10);
	obj.display();
	-obj ;
	obj.display();
	return 0;


}