#include <iostream>
using namespace std;

class Employee {
public:
	string Name;
	string Company;
	int age;
	void intro()
	{
		cout << "Name - " << Name << endl;
		cout << "Company - " << Company << endl;
		cout << "Age - " << age << endl;

	}
};

int main()
{
	Employee e1;
	e1.Name = "Ali Khan";
	e1.Company="APtech";
	e1.age = 25;
	e1.intro();

	Employee e2;
	e2.Name = "John";
	e2.Company = "Amazon";
	e2.age = 35;
	e2.intro();



}