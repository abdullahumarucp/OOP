#include"header.h"


int main()
{
	SavingsAccount saver1;
	SavingsAccount saver2;
	saver1.setSavingsBalance(2000.00);
	saver2.setSavingsBalance(3000.00);

	saver1.modifyInterestRate(0.04);
    saver2.modifyInterestRate(0.04);
	saver1.calculateMonthlyInterest();
	saver2.calculateMonthlyInterest();
	cout << " : For 4% annule intrest : " << endl;
	cout << "New Balance for Saver1=%f\n" <<
		saver1.getSavingsBalance();
	cout << endl;
	cout << "New Balance for Saver2=%f\n" <<
		saver2.getSavingsBalance();
	cout << endl;
	saver1.modifyInterestRate(0.05);
	saver2.modifyInterestRate(0.05);
	saver1.calculateMonthlyInterest();
	saver2.calculateMonthlyInterest();
	cout << " : For 5% annule intrest : " << endl;
	cout << "New Balance for Saver1=%f\n" <<
		saver1.getSavingsBalance();
	cout << endl;
	cout << "New Balance for Saver2=%f\n" <<
		saver2.getSavingsBalance(); 
	cout << endl;
	system("pause");
	return	0;
}