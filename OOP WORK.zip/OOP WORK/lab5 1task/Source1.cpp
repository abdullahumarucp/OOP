#include"header.h"
void SavingsAccount::setSavingsBalance(double a)
{
	balance = a;
}
void SavingsAccount::modifyInterestRate(double i)
{
	intrestrate = i;
}
void  SavingsAccount::calculateMonthlyInterest()
{
	 Mintrest = (intrestrate/12)*balance;
	// return Mintrest;
}
double SavingsAccount::getSavingsBalance()
{
	//cout << Mintrest << endl;
	balance = balance + Mintrest;
	//cout << "new balace : " << balance << endl;
	return balance;
}