#include<iostream>
using namespace std;


class SavingsAccount{
private:
	double	balance;
	double  intrestrate;
	double Mintrest;

public:

	void setSavingsBalance(double a);
	void modifyInterestRate(double i);
	void calculateMonthlyInterest();
	double getSavingsBalance();
};